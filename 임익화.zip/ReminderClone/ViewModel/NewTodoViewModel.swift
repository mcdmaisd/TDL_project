//
//  NewTodoViewModel.swift
//  ReminderClone
//
//  Created by ilim on 2024-07-15.
//

import Foundation

class NewTodoViewModel {
    
}
